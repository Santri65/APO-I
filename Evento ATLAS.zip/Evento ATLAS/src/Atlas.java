import java.util.Scanner;
public class Atlas {

    public static void main(String[] args){
        Scanner reader =new Scanner(System.in);
        
        System.out.println("Bienvenido a ATLAS, le ofrecemos hospedaje y transporte para el evento en bogota");
        
        System.out.println("Ofrecemos paquetes de 3 noches de hospedaje, una noche antes y una despues del concierto, cada noche cuesta 150 mil pero si compra al menos 3 noches le garantizamos un 10% de descuento");
        System.out.println("Cuantas noches desea hospedarse en el hotel? (minimo 1 maximo 4) ");
        int noches=reader.nextInt();
        reader.nextLine();
        double totalHospedaje=calcularHospedajes(noches);
        
        System.out.println("Para ir al concierto que medio de transporte escogera?[B] Bus o [A] Avion");
        String transporteIda=reader.nextLine();
        System.out.println("Para devolverse del concierto que medio de transporte escogera?[B] Bus o [A] Avion");
        String transporteDeVuelta=reader.nextLine();
        int totalTransporte=calcularTotalDeTransporte( transporteIda, transporteDeVuelta);
        
        double factura =totalTransporte+totalHospedaje;
        double cargoExtraDeFactura= factura*0.20;



        System.out.println("Por "+noches+" cantidad de noches, su hospedaje costara "+totalHospedaje);
        System.out.println("El total de su viaje ida y vuelta es de "+totalTransporte);
        System.out.println("Factura: El total de su viaje al concierto es "+factura);
        System.out.println("Su cargo extra del total es de "+cargoExtraDeFactura);
        double precioFinal=factura+cargoExtraDeFactura;
        System.out.println("El precio final es de "+precioFinal);
    }


    public static double calcularHospedajes(int noches){
        double precioNoche= 150000;
        if (noches<=0 && noches>4){
            System.out.println("No se pudo registrar la cantidad de noches, vuelva a intentar");
        }
        double totalHospedaje = precioNoche*noches;
        if (noches>=3){
            double porcentajeDescuento=0.10;
            double totalDescuento=totalHospedaje*porcentajeDescuento;
            totalHospedaje=totalHospedaje-totalDescuento;
        }
        return totalHospedaje;
    }

/**
 * descripcion ejemplo
 * @param String transport descripcion transport
 * @throws NullPointerException variable a puede no ser inicializada
 * @return int resultado dsecripcion resultado 
 */
    public static int calcularTotalDeTransporte(String transporteIda, String transporteDeVuelta){
        if (
            !transporteIda.equals("A") || !transporteIda.equals("B") ||
            !transporteDeVuelta.equals("A") || !transporteDeVuelta.equals("B")
        ){
            System.out.println("No es valido este digito");
        }
        int totalTransporte=0;
        int precioBus=80000;
        int precioAvion=250000;
        
        if (transporteIda.equals("B")){
            totalTransporte+=precioBus;
        } else{
            totalTransporte+=precioAvion;
        }
    
        if (transporteDeVuelta.equals("B")){
            totalTransporte=+precioBus;
        } else {
            totalTransporte=+precioAvion;
        }
        
        return totalTransporte;
    }





}
